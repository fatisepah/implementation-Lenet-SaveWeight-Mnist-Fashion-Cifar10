The Lenet-5 network consists of three Convolution layers, two Maxpooling, FullyConnected and three Relu, and in this project, the functions nn.conv2d, nn.linear, nn.relu, and nn.maxpool2d are used, and Train and Test are The network is implemented using Dataset Mnist, Fashion Mnist and Cifar-10. And after Train the network, the weights are saved with the .pt extension in Google Collab or on the server. At the end of the Test section, Accuracy (99.1) of the network is printed.

شبکه ی 
Lenet-5 
شامل سه تا لایه 
Convolution 
و دو تا 
Maxpooling و FullyConnected 
و سه تا 
Relu 
است و در این پروژه از توابع 
nn.conv2d و nn.linear و nn.relu و nn.maxpool2d 
استفاده شده است و 
Train و Test 
این شبکه با استفاده از 
Dataset Mnist و Fashion Mnist و Cifar-10 
پیاده سازی شده است. و بعد از 
Train 
شبکه، وزنها با پسوند 
.pt 
در کولب  گوگل و یا روی سرور ذخیره می شوند. در انتهای بخش 
Test 
آن 
Accuracy (99.1) 
شبکه چاپ می شود.